# sapper-svelte-meetup
This is a SPA where you can create meetups.

## Check it out:

Copy and paste this link in your browser:

SapperSvelteMeetup-env.eba-g6unusry.us-east-2.elasticbeanstalk.com
